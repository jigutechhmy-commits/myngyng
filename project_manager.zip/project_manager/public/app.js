const state = {
  config: null,
  contacts: [],
  selection: { type: 'J', shape: 'O' },
  selectedGroup: 'AS2',
  editingContactId: null
};

// 기본 형상 목록 (서버/클라이언트 양쪽에서 동일하게 사용할 수 있도록 클라이언트에도 보관)
const DEFAULT_SHAPES = [
  ...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''),
  'ㄱ', 'ㄴ', 'ㄷ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅅ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'
];

const els = {
  customer: document.getElementById('customerSelect'),
  date: document.getElementById('dateInput'),
  site: document.getElementById('siteSelect'),
  groupAuto: document.getElementById('groupAuto'),
  owner: document.getElementById('ownerInput'),
  ownerPosition: document.getElementById('ownerPosition'),
  title: document.getElementById('titleInput'),
  typeChips: document.getElementById('typeChips'),
  shapeList: document.getElementById('shapeList'),
  size: document.getElementById('sizeInput'),
  material: document.getElementById('materialSelect'),
  materialCustom: document.getElementById('materialCustom'),
  shapeDisplay: document.getElementById('shapeDisplay'),
  materialDisplay: document.getElementById('materialDisplay'),
  contactSelect: document.getElementById('contactSelect'),
  contactPhone: document.getElementById('contactPhone'),
  contactEmail: document.getElementById('contactEmail'),
  codeString: document.getElementById('codeString'),
  folderPath: document.getElementById('folderPath'),
  previewBtn: document.getElementById('previewBtn'),
  createBtn: document.getElementById('createBtn'),
  contactTable: document.getElementById('contactTable'),
  abCustomer: document.getElementById('abCustomer'),
  abGroup: document.getElementById('abGroup'),
  abPosition: document.getElementById('abPosition'),
  abName: document.getElementById('abName'),
  abPhone: document.getElementById('abPhone'),
  abEmail: document.getElementById('abEmail'),
  addContactBtn: document.getElementById('addContactBtn'),
  cancelEditBtn: document.getElementById('cancelEditBtn')
};

init();

async function init() {
  setToday();
  await loadConfig();
  await loadContacts();
  bindInputs();
  renderTypes();
  renderShapes();
  refreshPreview();
}

function setToday() {
  const t = today();
  els.date.value = t;
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

async function loadConfig() {
  const res = await fetch('/api/config');
  state.config = await res.json();
  // 형상/소재가 비어 있을 때 클라이언트 기본값으로 보정
  if (!state.config.shapes || !state.config.shapes.length) {
    state.config.shapes = DEFAULT_SHAPES;
  }
  fillSelect(els.customer, state.config.customers);
  fillSites();
  fillAbGroups();
  fillMaterials();
  ensureShapeSelection();
  ensureMaterialSelection();
  if (!state.selectedGroup) state.selectedGroup = 'AS2';
  if (els.groupAuto && !els.groupAuto.value) els.groupAuto.value = state.selectedGroup;
}

function fillAbGroups() {
  if (!els.abGroup) return;
  const groups = state.config?.groups || [];
  els.abGroup.innerHTML = '<option value="">선택</option>';
  (groups || []).forEach((g) => {
    const opt = document.createElement('option');
    opt.value = g;
    opt.textContent = g;
    els.abGroup.appendChild(opt);
  });
}

async function loadContacts() {
  const res = await fetch('/api/address-book');
  const data = await res.json();
  state.contacts = data.contacts || [];
  renderContactOptions();
  renderContactTable();
}

function fillSelect(select, items, { labelKey = 'label', valueKey = 'id' } = {}) {
  select.innerHTML = '';
  (items || []).forEach((item) => {
    const isObj = item && typeof item === 'object';
    const value = isObj ? item[valueKey] ?? item.id ?? item.value : item;
    const label = isObj ? (item[labelKey] ? `${value} · ${item[labelKey]}` : value) : item;
    if (!value && value !== 0) return;
    const opt = document.createElement('option');
    opt.value = value;
    opt.textContent = label;
    select.appendChild(opt);
  });
}

function fillMaterials() {
  fillSelect(els.material, state.config.materials, { labelKey: 'label', valueKey: 'id' });
  toggleMaterialCustom();
}

function ensureMaterialSelection() {
  if (!state.config?.materials?.length) return;
  const firstId = state.config.materials[0].id;
  if (!els.material.value || !state.config.materials.find((m) => m.id === els.material.value)) {
    els.material.value = firstId;
  }
}

function ensureShapeSelection() {
  if (!state.config?.shapes?.length) return;
  if (!state.selection.shape) {
    state.selection.shape = state.config.shapes[0];
  }
}

function toggleMaterialCustom() {
  const useCustom = els.material.value === '__CUSTOM__';
  els.materialCustom.classList.toggle('hidden', !useCustom);
  
  // 부모 컨테이너(two-col)의 레이아웃 제어를 위해 클래스 추가
  const container = els.material.closest('.two-col');
  if (container) {
    container.classList.toggle('is-custom', useCustom);
  }
  
  if (useCustom) {
    els.materialCustom.placeholder = '영문 약어 직접 입력';
    els.materialCustom.focus();
  } else {
    els.materialCustom.value = '';
  }
}

function expandMaterialList() {
  const maxSize = Math.min(10, els.material.options.length || 10);
  els.material.setAttribute('size', maxSize);
  els.material.classList.add('expanded');
}

function collapseMaterialList() {
  els.material.removeAttribute('size');
  els.material.classList.remove('expanded');
}

function fillSites() {
  els.site.innerHTML = '';
  state.config.sites.forEach((s) => {
    const opt = document.createElement('option');
    opt.value = s.id;
    opt.textContent = s.label;
    els.site.appendChild(opt);
  });
}

function renderTypes() {
  els.typeChips.innerHTML = '';
  state.config.types.forEach((t) => {
    const btn = document.createElement('button');
    btn.className = 'chip' + (state.selection.type === t.id ? ' active' : '');
    btn.textContent = `${t.id} · ${t.label}`;
    btn.onclick = () => {
      state.selection.type = t.id;
      renderTypes();
      refreshPreview();
    };
    els.typeChips.appendChild(btn);
  });
}

function renderShapes() {
  els.shapeList.innerHTML = '';
  ensureShapeSelection();
  if (!state.config.shapes || !state.config.shapes.length) {
    const empty = document.createElement('div');
    empty.className = 'micro';
    empty.textContent = '형상 문자가 설정되어 있지 않습니다.';
    els.shapeList.appendChild(empty);
    return;
  }
  state.config.shapes.forEach((s) => {
    const btn = document.createElement('div');
    btn.className = 'shape' + (state.selection.shape === s ? ' active' : '');
    btn.textContent = s;
    btn.onclick = () => {
      state.selection.shape = s;
      renderShapes();
      refreshPreview();
    };
    els.shapeList.appendChild(btn);
  });
}

function bindInputs() {
  [
    els.customer,
    els.date,
    els.site,
    els.owner,
    els.ownerPosition,
    els.title,
    els.size
  ].forEach((el) => el.addEventListener('input', refreshPreview));

  els.material.addEventListener('change', () => {
    toggleMaterialCustom();
    refreshPreview();
    collapseMaterialList();
  });
  els.material.addEventListener('focus', expandMaterialList);
  els.material.addEventListener('blur', collapseMaterialList);
  els.materialCustom.addEventListener('input', refreshPreview);

  els.contactSelect.addEventListener('change', onContactSelect);
  // 연락처 입력은 프리뷰에 영향을 주지 않으므로 별도 핸들러 불필요

  els.previewBtn.addEventListener('click', refreshPreview);
  els.createBtn.addEventListener('click', createProject);
  els.addContactBtn.addEventListener('click', upsertContact);
  els.cancelEditBtn?.addEventListener('click', resetEditForm);
  els.customer.addEventListener('change', () => {
    renderContactOptions();
    refreshPreview();
  });
}

function renderContactOptions() {
  const list = state.contacts.filter((c) => c.customer === els.customer.value);
  els.contactSelect.innerHTML = '<option value="">주소록 선택 없음</option>';
  list.forEach((c) => {
    const opt = document.createElement('option');
    opt.value = c.id;
    opt.textContent = `${c.group || '-'} · ${c.name}${c.position ? ' · ' + c.position : ''}`;
    els.contactSelect.appendChild(opt);
  });
  els.contactSelect.value = '';
  els.contactPhone.value = '';
  els.contactEmail.value = '';
}

function onContactSelect() {
  const id = els.contactSelect.value;
  const found = state.contacts.find((c) => c.id === id);
  if (found) {
    els.owner.value = found.name || '';
    els.contactPhone.value = found.phone || '';
    els.contactEmail.value = found.email || '';
    // 그룹은 입력 UI가 없으므로 주소록 값으로 state에 고정
    state.selectedGroup = found.group || state.selectedGroup || 'AS2';
    if (els.groupAuto) els.groupAuto.value = state.selectedGroup;

    // 직급도 주소록 값이 있으면 자동 입력
    if (found.position) {
      // 옵션에 없으면 추가 후 선택
      const exists = Array.from(els.ownerPosition.options).some((o) => o.value === found.position);
      if (!exists) {
        const opt = document.createElement('option');
        opt.value = found.position;
        opt.textContent = found.position;
        els.ownerPosition.appendChild(opt);
      }
      els.ownerPosition.value = found.position;
    }
  }
  refreshPreview();
}

function gatherPayload() {
  const group = (state.selectedGroup || 'AS2').trim() || 'AS2';
  const materialInput =
    els.material.value === '__CUSTOM__' ? (els.materialCustom.value || '') : els.material.value;
  const materialCode = (materialInput || 'ST').replace(/[ㄱ-ㅎ가-힣]/g, '').trim().toUpperCase();
  return {
    customer: els.customer.value,
    date: els.date.value,
    site: els.site.value,
    group,
    owner: els.owner.value,
    ownerPosition: els.ownerPosition.value,
    title: els.title.value,
    type: state.selection.type,
    shape: state.selection.shape,
    size: els.size.value || '000',
    material: materialCode,
    contact: {
      phone: els.contactPhone.value,
      email: els.contactEmail.value
    }
  };
}

async function refreshPreview() {
  const payload = gatherPayload();
  ensureShapeSelection();
  ensureMaterialSelection();
  try {
    const res = await fetch('/api/preview-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    const code = data.code || '코드 미리보기';
    els.codeString.textContent = code;
    const root = state.config?.outputRoot || 'Desktop';
    const folderName = data.folderName || code;
    els.folderPath.textContent = `${root}\\${folderName}`;

    // 디스플레이용 텍스트 업데이트
    const shapeText = state.selection.shape || '-';
    const materialObj = (state.config?.materials || []).find((m) => m.id === payload.material);
    const materialText = materialObj ? materialObj.label : payload.material || '-';
    if (els.shapeDisplay) els.shapeDisplay.textContent = `형상: ${shapeText}`;
    if (els.materialDisplay) els.materialDisplay.textContent = `소재: ${materialText}`;
  } catch (err) {
    els.codeString.textContent = '코드 미리보기 (에러)';
  }
}

async function createProject() {
  const payload = gatherPayload();
  els.createBtn.disabled = true;
  els.createBtn.textContent = '생성 중...';
  try {
    const res = await fetch('/api/create-project', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    if (data.ok) {
      alert(`생성 완료!\n${data.folder}`);
      refreshPreview();
    } else {
      alert('생성 실패. 입력을 확인하세요.');
    }
  } catch (err) {
    alert('생성 중 오류: ' + err.message);
  } finally {
    els.createBtn.disabled = false;
    els.createBtn.textContent = '프로젝트 생성';
  }
}

function resetEditForm() {
  state.editingContactId = null;
  els.addContactBtn.textContent = '주소록 추가';
  els.cancelEditBtn?.classList.add('hidden');
  els.abCustomer.value = '';
  els.abGroup.value = '';
  if (els.abPosition) els.abPosition.value = '';
  els.abName.value = '';
  els.abPhone.value = '';
  els.abEmail.value = '';
}

async function upsertContact() {
  const body = {
    customer: els.abCustomer.value || els.customer.value || '하나머티리얼즈',
    group: els.abGroup.value,
    position: els.abPosition?.value || '',
    name: els.abName.value,
    phone: els.abPhone.value,
    email: els.abEmail.value
  };
  if (!body.name) {
    alert('이름은 필수입니다.');
    return;
  }
  const url = state.editingContactId ? `/api/address-book/${state.editingContactId}` : '/api/address-book';
  const method = state.editingContactId ? 'PUT' : 'POST';
  await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  resetEditForm();
  await loadContacts();
  renderContactOptions();
}

function renderContactTable() {
  const header = `<header><div>고객사</div><div>그룹</div><div>직급</div><div>이름</div><div>전화</div><div>메일</div><div></div></header>`;
  const rows = state.contacts
    .map(
      (c) => `<div class="row-line">
        <div>${c.customer}</div>
        <div>${c.group || '-'}</div>
        <div>${c.position || '-'}</div>
        <div>${c.name}</div>
        <div>${c.phone || '-'}</div>
        <div>${c.email || '-'}</div>
        <div style="display:flex; gap:6px; justify-content:flex-end;">
          <button class="ghost" data-edit="${c.id}">수정</button>
          <button class="ghost" data-id="${c.id}">삭제</button>
        </div>
      </div>`
    )
    .join('');
  els.contactTable.innerHTML = header + rows;
  els.contactTable.querySelectorAll('button[data-id]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      await fetch(`/api/address-book/${btn.dataset.id}`, { method: 'DELETE' });
      await loadContacts();
      renderContactOptions();
    })
  );

  els.contactTable.querySelectorAll('button[data-edit]').forEach((btn) =>
    btn.addEventListener('click', () => {
      const id = btn.dataset.edit;
      const c = state.contacts.find((x) => x.id === id);
      if (!c) return;
      state.editingContactId = id;
      els.addContactBtn.textContent = '수정 저장';
      els.cancelEditBtn?.classList.remove('hidden');
      els.abCustomer.value = c.customer || '';
      // 그룹: 옵션에 없으면 임시 옵션을 추가해 값이 사라지지 않게 함
      if (c.group) {
        const existsGroup = Array.from(els.abGroup.options).some((o) => o.value === c.group);
        if (!existsGroup) {
          const opt = document.createElement('option');
          opt.value = c.group;
          opt.textContent = c.group;
          els.abGroup.appendChild(opt);
        }
      }
      els.abGroup.value = c.group || '';

      // 직급: 옵션에 없으면 임시 옵션 추가
      if (els.abPosition) {
        if (c.position) {
          const existsPos = Array.from(els.abPosition.options).some((o) => o.value === c.position);
          if (!existsPos) {
            const opt = document.createElement('option');
            opt.value = c.position;
            opt.textContent = c.position;
            els.abPosition.appendChild(opt);
          }
        }
        els.abPosition.value = c.position || '';
      }
      els.abName.value = c.name || '';
      els.abPhone.value = c.phone || '';
      els.abEmail.value = c.email || '';
    })
  );
}

