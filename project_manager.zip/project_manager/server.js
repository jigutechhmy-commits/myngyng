const express = require('express');
const path = require('path');
const os = require('os');
const fs = require('fs');
const fsp = require('fs/promises');
const fse = require('fs-extra');
const { nanoid } = require('nanoid');

const app = express();
const PORT = process.env.PORT || 3000;

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const TEMPLATE_DIR = path.join(ROOT, 'templates');
const CONFIG_PATH = path.join(DATA_DIR, 'config.json');
const ADDRESS_BOOK_PATH = path.join(DATA_DIR, 'addressBook.json');

app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(ROOT, 'public')));

const defaultConfig = () => ({
  outputRoot: path.join(os.homedir(), 'Desktop'),
  nxTemplatePath: path.join(TEMPLATE_DIR, 'START NX01.prt'),
  quotationTemplatePath: path.join(TEMPLATE_DIR, 'quotation.html'),
  customers: ['하나머티리얼즈'],
  sites: [
    { id: 'A', label: 'AS (아산)' },
    { id: 'C', label: 'CA (천안)' }
  ],
  groups: ['AS1', 'AS2', 'AS3', 'CA1', 'RND1', 'RND2', 'QE1', 'QE2', '품질', '홀가공', '공구실'],
  types: [
    { id: 'J', label: 'JIG' },
    { id: 'T', label: 'TOOL' },
    { id: 'F', label: 'FURNITURE' }
  ],
  materials: [
    { id: 'SC', label: 'S45C' },
    { id: 'AL', label: 'ALUMINIUM' },
    { id: 'SS', label: 'SUS304' },
    { id: 'SK', label: 'SKD-11' },
    { id: 'PV', label: 'PVC' },
    { id: 'PC', label: 'PC' },
    { id: 'PP', label: 'PP' },
    { id: 'PE', label: 'PE' },
    { id: 'PK', label: 'PEEK' },
    { id: 'PU', label: 'PU' },
    { id: 'PT', label: 'PTFE' },
    { id: 'PO', label: 'POM' },
    { id: 'MN', label: 'MC NYLON' },
    { id: '__CUSTOM__', label: '직접입력' }
  ],
  shapes: [
    ...'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split(''),
    'ㄱ', 'ㄴ', 'ㄷ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅅ', 'ㅇ', 'ㅈ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ'
  ]
});

async function ensureDataFiles() {
  await fse.ensureDir(DATA_DIR);
  await fse.ensureDir(TEMPLATE_DIR);

  if (!fs.existsSync(CONFIG_PATH)) {
    await fsp.writeFile(CONFIG_PATH, JSON.stringify(defaultConfig(), null, 2), 'utf8');
  }
  if (!fs.existsSync(ADDRESS_BOOK_PATH)) {
    await fsp.writeFile(ADDRESS_BOOK_PATH, JSON.stringify({ contacts: [] }, null, 2), 'utf8');
  }
}

async function loadJson(filePath, fallback) {
  try {
    const raw = await fsp.readFile(filePath, 'utf8');
    return JSON.parse(raw);
  } catch (err) {
    return fallback;
  }
}

async function saveJson(filePath, data) {
  await fsp.writeFile(filePath, JSON.stringify(data, null, 2), 'utf8');
}

function pad2(n) {
  return String(n).padStart(2, '0');
}

const GROUP_CODE_MAP = {
  AS1: 'A1',
  AS2: 'A2',
  AS3: 'A3',
  CA1: 'C1',
  RND1: 'R1',
  RND2: 'R2',
  QE1: 'Q1',
  QE2: 'Q2',
  품질: 'QC',
  홀가공: 'HM',
  공구실: 'TL'
};

function customerToCode(customer) {
  if (customer === '하나머티리얼즈') return 'H';
  const seg = sanitizeSegment(customer || '').toUpperCase();
  return seg ? seg[0] : 'X';
}

function customerSiteToCode2(customer, site) {
  // 고객사+사업장 2자리 코드 (예: 하나머티리얼즈 아산=HA, 천안=HC)
  const c = customerToCode(customer).slice(0, 1);
  const s = sanitizeSegment(site || '').toUpperCase().slice(0, 1);
  // 기존 사이트 id가 A(아산), C(천안) 형태이므로 그대로 사용
  return (c + (s || 'X')).slice(0, 2);
}

function normalizeGroupCode(groupRaw) {
  const group = (groupRaw || '').trim();
  if (!group) return 'A2';
  if (GROUP_CODE_MAP[group]) return GROUP_CODE_MAP[group];
  const up = group.toUpperCase();
  if (/^[A-Z][0-9]$/.test(up) || /^[A-Z]{2}$/.test(up)) return up;
  const m1 = up.match(/^AS(\d)$/);
  if (m1) return `A${m1[1]}`;
  const m2 = up.match(/^CA(\d)$/);
  if (m2) return `C${m2[1]}`;
  const m3 = up.match(/^RND(\d)$/);
  if (m3) return `R${m3[1]}`;
  const m4 = up.match(/^QE(\d)$/);
  if (m4) return `Q${m4[1]}`;
  return 'A2';
}

function normalizeShape(shape) {
  const s = (shape || '').trim();
  return s ? s[0] : 'O';
}

function normalizeMaterial(material) {
  const m = (material || '').replace(/[ㄱ-ㅎ가-힣]/g, '').trim().toUpperCase();
  const two = m.slice(0, 2);
  return (two || '00').padEnd(2, '0');
}

function normalizeSize2(sizeMm) {
  const n = Number(sizeMm);
  if (!Number.isFinite(n) || n <= 0) return '00';
  const code = Math.round(n / 10);
  const clamped = Math.max(0, Math.min(99, code));
  return pad2(clamped);
}

function sanitizeSegment(text) {
  if (!text) return '';
  return text.replace(/[<>:"/\\|?*]/g, '-').replace(/\s+/g, '_');
}

function buildDrawingCode(payload) {
  // 도면번호 체계(최종): 총 10자리
  // [1][2][3–4][5–6][7–8][9–10]
  // [1] 타입(J/T/F), [2] 형상(한글 자음 또는 영문 1자)
  // [3-4] 사이즈(코드*10=mm, 00=미확정), [5-6] 소재(2자 약어)
  // [7-8] 고객사+사업장(2자 코드: HA/HC 등), [9-10] 그룹(2자 코드)
  const type = (payload.type || 'J').toUpperCase().slice(0, 1);
  const shape = normalizeShape(payload.shape);
  const size2 = normalizeSize2(payload.size);
  const material2 = normalizeMaterial(payload.material);
  const customerSite2 = customerSiteToCode2(payload.customer, payload.site);
  const group2 = normalizeGroupCode(payload.group);
  return `${type}${shape}${size2}${material2}${customerSite2}${group2}`;
}

function buildFolderName(payload) {
  const customerName = payload.customer === '하나머티리얼즈' ? 'H' : payload.customer;
  const parts = [
    customerName,
    payload.group || payload.groupCustom,
    payload.owner,
    payload.title
  ]
    .map((v) => sanitizeSegment(v || ''))
    .filter(Boolean);
  const joined = parts.join('_');
  return joined || sanitizeSegment(payload.code || payload.title || 'PROJECT');
}

async function getConfig() {
  const base = defaultConfig();
  const loaded = await loadJson(CONFIG_PATH, base);
  
  // 소재 목록은 코드의 최신 목록을 우선시하거나 병합합니다.
  const baseMaterials = base.materials || [];
  const loadedMaterials = loaded.materials || [];
  
  const materialMap = new Map();
  // 기본 목록 추가
  baseMaterials.forEach(m => materialMap.set(m.id, m));
  // 기존 저장된 목록 중 커스텀이 아닌 것들 병합 (기본 목록에 없는 것이 있다면 유지)
  loadedMaterials.forEach(m => {
    if (m && m.id && m.id !== '__CUSTOM__') {
      materialMap.set(m.id, m);
    }
  });

  const finalMaterials = Array.from(materialMap.values());
  // 직접입력은 항상 마지막에 위치
  if (!finalMaterials.find(m => m.id === '__CUSTOM__')) {
    finalMaterials.push({ id: '__CUSTOM__', label: '직접입력' });
  }

  const shapes =
    loaded.shapes && Array.isArray(loaded.shapes) && loaded.shapes.length
      ? loaded.shapes
      : base.shapes;

  return {
    ...base,
    ...loaded,
    customers: loaded.customers || base.customers,
    sites: loaded.sites || base.sites,
    groups: loaded.groups || base.groups,
    types: loaded.types || base.types,
    materials: finalMaterials,
    shapes
  };
}

async function getAddressBook() {
  return loadJson(ADDRESS_BOOK_PATH, { contacts: [] });
}

function projectMemoHtml(data) {
  const {
    code,
    title,
    owner,
    ownerPosition,
    customer,
    siteLabel,
    group,
    contact,
    orders,
    memo
  } = data;

  return `<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8"/>
  <title>${code} MEMO</title>
  <style>
    * { box-sizing:border-box; font-family:'Pretendard','Noto Sans KR', 'Segoe UI', sans-serif; }
    body { margin:0; padding:15px; background:#f6f7f8; color:#1f2933; }
    .sheet { width: 100%; max-width: 1080px; margin:0 auto; background:#fff; padding:20px; border:1px solid #e5e7eb; border-radius:12px; box-shadow:0 10px 25px rgba(0,0,0,0.05); }
    .top { display:flex; justify-content:space-between; gap:16px; align-items:flex-start; border-bottom:1px solid #eceef1; padding-bottom:12px; }
    .eyebrow { color:#6b7280; font-size:11px; letter-spacing:0.08em; text-transform:uppercase; }
    .title-inputs { display:flex; gap:8px; margin-top:8px; }
    .title-inputs input { flex:1; padding:8px 10px; border:1px solid #d7dbe0; border-radius:8px; font-size:14px; }
    .title-display { margin-top:8px; font-size:20px; font-weight:700; color:#0f1720; }
    .subtitle { margin-top:4px; color:#6b7280; font-size:13px; }
    .code-tag { padding:8px 12px; border:1px solid #d7dbe0; border-radius:10px; background:#f9fafb; font-weight:700; min-width:120px; text-align:center; font-size:14px; }
    
    .grid { display:grid; gap:12px; grid-template-columns: repeat(3, 1fr); margin-top:12px; }
    .card { border:1px solid #eceef1; border-radius:10px; padding:12px; background:#fbfcfd; }
    .card h3 { margin:0 0 8px; font-size:14px; color:#0f1720; border-left:3px solid #111827; padding-left:8px; }
    .row { display:flex; gap:8px; flex-wrap:wrap; margin-bottom:8px; }
    label { display:flex; flex-direction:column; gap:4px; color:#6b7280; font-size:11px; flex:1; min-width:120px; }
    input, textarea { padding:8px 10px; border:1px solid #d7dbe0; border-radius:8px; font-size:13px; width:100%; }
    textarea { resize:none; min-height:80px; }
    
    table { width:100%; border-collapse:collapse; margin-top:6px; }
    th, td { border:1px solid #e5e7eb; padding:6px; text-align:left; font-size:12px; }
    th { background:#f2f4f6; color:#4b5563; font-weight:600; }
    
    .actions { display:flex; gap:6px; justify-content:flex-end; margin-top:10px; }
    button { border:1px solid #d7dbe0; background:#fff; padding:8px 12px; border-radius:8px; cursor:pointer; font-weight:600; color:#1f2933; font-size:12px; }
    button.primary { background:#111827; color:#f9fafb; border-color:#111827; }
    button.ghost { background:#f5f6f7; }
    
    .image-box { border:1px dashed #d7dbe0; border-radius:10px; padding:8px; background:#fff; height:180px; display:flex; align-items:center; justify-content:center; }
    .image-box img { max-width:100%; max-height:100%; object-fit:contain; }
    .fallback { color:#9ca3af; font-size:12px; }
    
    @media print {
      /* A4 가로 1장에 강제 수용 */
      @page { size: A4 landscape; margin: 0; }
      html, body { width: 297mm; height: 210mm; margin:0; padding:0; background:#fff; }

      /* 실제 프린트 영역(스케일 적용 대상) */
      .sheet { border:none; box-shadow:none; width: 297mm; height: 210mm; max-width:none; padding:8mm; overflow:hidden; transform-origin: top left; }

      button, .actions, .hint { display:none !important; }
      input, textarea { border:none; padding:2px 0; background: transparent; }
      .card { background:#fff; border:1px solid #eee; break-inside: avoid; page-break-inside: avoid; }
      .grid, .row { break-inside: avoid; page-break-inside: avoid; }
      .image-box { height: 220px; }
    }
  </style>
</head>
<body>
  <div class="sheet" id="printRoot">
    <header class="top">
      <div>
        <div class="eyebrow">${customer || ''} · ${siteLabel || ''}</div>
        <div class="title-inputs">
          <input id="itemCode" placeholder="품목코드" autocomplete="off">
          <input id="itemName" placeholder="품목명" autocomplete="off">
        </div>
        <div class="title-display" id="titleDisplay">품목코드 · 품목명</div>
        <div class="subtitle">가제: ${title || '-'} / 도면번호: ${code}</div>
      </div>
      <div class="code-tag">${code}</div>
    </header>

    <section class="grid">
      <div class="card">
        <h3>제품 기본 정보</h3>
        <div class="row">
          <label>그룹<input id="group" placeholder="예: AS2"></label>
          <label>담당자<input id="owner" placeholder="담당자 이름"></label>
          <label>직급<input id="ownerPosition" placeholder="예: 선임"></label>
        </div>
        <div class="row">
          <label>마킹번호<input id="marking" placeholder="마킹번호"></label>
          <label>규격<input id="spec" placeholder="규격 (예: 100x100)"></label>
          <label>소재<input id="materialNote" placeholder="소재 (예: SC, AL 등)"></label>
        </div>
      </div>
      <div class="card">
        <h3>담당자 정보</h3>
        <div class="row">
          <label>이름<input id="contactName" value="${contact?.name || owner || ''}"></label>
          <label>직급<input id="contactPosition" value="${contact?.position || ownerPosition || ''}"></label>
        </div>
        <div class="row">
          <label>연락처<input id="contactPhone" value="${contact?.phone || ''}"></label>
          <label>이메일<input id="contactEmail" value="${contact?.email || ''}"></label>
        </div>
      </div>
      <div class="card">
        <h3>기타 정보</h3>
        <div class="row">
          <label>고객사<input value="${customer || '-'}" disabled></label>
          <label>사업장<input value="${siteLabel || '-'}" disabled></label>
        </div>
        <div class="row">
          <label>도면번호<input value="${code}" disabled></label>
        </div>
      </div>
    </section>

    <section class="grid" style="grid-template-columns: 1.5fr 1fr;">
      <div class="card">
        <h3>발주 / 납품 이력</h3>
        <table id="orderTable">
          <thead><tr><th>#</th><th>발주일</th><th>납품일</th><th>수량</th><th class="actions"></th></tr></thead>
          <tbody id="orderBody"></tbody>
        </table>
        <div class="actions" style="justify-content: flex-start;">
          <button id="addOrder" class="ghost">+ 추가</button>
        </div>
      </div>
      <div class="card" style="display:flex; flex-direction:column;">
        <h3>메모</h3>
        <textarea id="memoBox" style="flex:1;">${memo || ''}</textarea>
        <div class="actions">
          <button id="printBtn">인쇄/PDF</button>
          <button id="saveBtn" class="primary">저장</button>
        </div>
      </div>
    </section>

    <section class="card" style="margin-top:12px;">
      <h3>형상 이미지</h3>
      <div class="image-box">
        <img id="shapeImg" style="display:none;">
        <div id="imgFallback" class="fallback">이미지 없음 (${code}.jpg)</div>
      </div>
    </section>
  </div>

  <script>
    const drawingCode = '${code}';
    const STORAGE_KEY = 'memo-' + drawingCode;
    const initialState = ${JSON.stringify({
      itemCode: '',
      itemName: '',
      marking: '',
      spec: '',
      materialNote: '',
      group: group || '',
      owner: owner || '',
      ownerPosition: ownerPosition || '',
      contact: {
        name: contact?.name || owner || '',
        position: contact?.position || ownerPosition || '',
        phone: contact?.phone || '',
        email: contact?.email || ''
      },
      orders: orders && orders.length ? orders : [{ orderDate: '', deliveryDate: '', qty: '' }],
      memo: memo || ''
    })};

    let state = loadState();

    const els = {
      itemCode: document.getElementById('itemCode'),
      itemName: document.getElementById('itemName'),
      titleDisplay: document.getElementById('titleDisplay'),
      group: document.getElementById('group'),
      owner: document.getElementById('owner'),
      ownerPosition: document.getElementById('ownerPosition'),
      marking: document.getElementById('marking'),
      spec: document.getElementById('spec'),
      materialNote: document.getElementById('materialNote'),
      contactName: document.getElementById('contactName'),
      contactPosition: document.getElementById('contactPosition'),
      contactPhone: document.getElementById('contactPhone'),
      contactEmail: document.getElementById('contactEmail'),
      memo: document.getElementById('memoBox'),
      orderBody: document.getElementById('orderBody'),
      addOrder: document.getElementById('addOrder'),
      save: document.getElementById('saveBtn'),
      print: document.getElementById('printBtn'),
      img: document.getElementById('shapeImg'),
      imgFallback: document.getElementById('imgFallback')
    };

    function loadState() {
      try {
        const saved = localStorage.getItem(STORAGE_KEY);
        if (saved) return { ...initialState, ...JSON.parse(saved) };
      } catch (e) {}
      return { ...initialState };
    }

    function saveState() {
      state = collect();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      updateTitle();
      alert('저장되었습니다.');
    }

    function collect() {
      return {
        itemCode: els.itemCode.value,
        itemName: els.itemName.value,
        group: els.group.value,
        owner: els.owner.value,
        ownerPosition: els.ownerPosition.value,
        marking: els.marking.value,
        spec: els.spec.value,
        materialNote: els.materialNote.value,
        contact: {
          name: els.contactName.value,
          position: els.contactPosition.value,
          phone: els.contactPhone.value,
          email: els.contactEmail.value
        },
        orders: Array.from(els.orderBody.querySelectorAll('tr')).map(tr => ({
          orderDate: tr.querySelector('[data-key="orderDate"]').value,
          deliveryDate: tr.querySelector('[data-key="deliveryDate"]').value,
          qty: tr.querySelector('[data-key="qty"]').value
        })),
        memo: els.memo.value
      };
    }

    function render() {
      els.itemCode.value = state.itemCode;
      els.itemName.value = state.itemName;
      els.group.value = state.group || ${JSON.stringify(group || '')};
      els.owner.value = state.owner || ${JSON.stringify(owner || '')};
      els.ownerPosition.value = state.ownerPosition || ${JSON.stringify(ownerPosition || '')};
      els.marking.value = state.marking;
      els.spec.value = state.spec;
      els.materialNote.value = state.materialNote;
      els.contactName.value = state.contact.name;
      els.contactPosition.value = state.contact.position;
      els.contactPhone.value = state.contact.phone;
      els.contactEmail.value = state.contact.email;
      els.memo.value = state.memo;
      renderOrders();
      updateTitle();
      loadImage();
    }

    function renderOrders() {
      els.orderBody.innerHTML = '';
      state.orders.forEach((row, idx) => {
        const tr = document.createElement('tr');
        tr.innerHTML = \`
          <td>\${idx + 1}</td>
          <td><input type="date" value="\${row.orderDate}" data-key="orderDate"></td>
          <td><input type="date" value="\${row.deliveryDate}" data-key="deliveryDate"></td>
          <td><input type="number" value="\${row.qty}" data-key="qty" style="width:60px;"></td>
          <td class="actions"><button class="remove ghost" style="padding:4px 8px;">삭제</button></td>
        \`;
        tr.querySelector('.remove').onclick = () => {
          tr.remove();
          autoSave();
        };
        tr.querySelectorAll('input').forEach(i => i.oninput = autoSave);
        els.orderBody.appendChild(tr);
      });
    }

    function updateTitle() {
      const code = els.itemCode.value.trim();
      const name = els.itemName.value.trim();
      els.titleDisplay.textContent = (code || name) ? (code + ' · ' + name) : '품목코드 · 품목명';
      document.title = (code || name) ? (code + ' MEMO') : (drawingCode + ' MEMO');
    }

    function loadImage() {
      els.img.src = drawingCode + '.jpg';
      els.img.onload = () => { els.img.style.display = 'block'; els.imgFallback.style.display = 'none'; };
      els.img.onerror = () => { els.img.style.display = 'none'; els.imgFallback.style.display = 'block'; };
    }

    let timer;
    function autoSave() {
      clearTimeout(timer);
      timer = setTimeout(() => {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(collect()));
        updateTitle();
      }, 500);
    }

    els.addOrder.onclick = () => {
      state.orders.push({ orderDate: '', deliveryDate: '', qty: '' });
      renderOrders();
    };
    els.save.onclick = saveState;
    function fitToSinglePage() {
      const root = document.getElementById('printRoot');
      if (!root) return;

      // A4 landscape 실제 픽셀 크기 측정 (브라우저/프린터 설정에 따라 px이 달라져서 mm로 측정)
      const probe = document.createElement('div');
      probe.style.position = 'fixed';
      probe.style.left = '-10000px';
      probe.style.top = '-10000px';
      probe.style.width = '297mm';
      probe.style.height = '210mm';
      document.body.appendChild(probe);
      const page = probe.getBoundingClientRect();
      probe.remove();

      // 스케일 초기화 후 실제 콘텐츠 크기 측정
      root.style.transform = '';
      const contentW = root.scrollWidth;
      const contentH = root.scrollHeight;
      const scale = Math.min(1, page.width / contentW, page.height / contentH);
      root.style.transformOrigin = 'top left';
      root.style.transform = 'scale(' + scale + ')';
    }

    function resetScale() {
      const root = document.getElementById('printRoot');
      if (root) root.style.transform = '';
    }

    window.addEventListener('beforeprint', fitToSinglePage);
    window.addEventListener('afterprint', resetScale);

    els.print.onclick = () => {
      fitToSinglePage();
      window.print();
    };
    [els.itemCode, els.itemName, els.group, els.owner, els.ownerPosition, els.marking, els.spec, els.materialNote, els.contactName, els.contactPosition, els.contactPhone, els.contactEmail, els.memo].forEach(el => el.oninput = autoSave);

    render();
  </script>
</body>
</html>`;
}

app.get('/api/config', async (_req, res) => {
  const config = await getConfig();
  res.json(config);
});

app.get('/api/address-book', async (_req, res) => {
  const book = await getAddressBook();
  res.json(book);
});

app.post('/api/address-book', async (req, res) => {
  const book = await getAddressBook();
  const entry = {
    id: nanoid(),
    customer: req.body.customer || '하나머티리얼즈',
    group: req.body.group || '',
    position: req.body.position || '',
    name: req.body.name || '',
    phone: req.body.phone || '',
    email: req.body.email || ''
  };
  book.contacts.push(entry);
  await saveJson(ADDRESS_BOOK_PATH, book);
  res.json(entry);
});

app.put('/api/address-book/:id', async (req, res) => {
  const book = await getAddressBook();
  const idx = book.contacts.findIndex((c) => c.id === req.params.id);
  if (idx < 0) {
    res.status(404).json({ ok: false, message: 'not found' });
    return;
  }
  const prev = book.contacts[idx];
  const next = {
    ...prev,
    customer: req.body.customer ?? prev.customer,
    group: req.body.group ?? prev.group,
    position: req.body.position ?? prev.position,
    name: req.body.name ?? prev.name,
    phone: req.body.phone ?? prev.phone,
    email: req.body.email ?? prev.email
  };
  book.contacts[idx] = next;
  await saveJson(ADDRESS_BOOK_PATH, book);
  res.json(next);
});

app.delete('/api/address-book/:id', async (req, res) => {
  const book = await getAddressBook();
  const filtered = book.contacts.filter((c) => c.id !== req.params.id);
  book.contacts = filtered;
  await saveJson(ADDRESS_BOOK_PATH, book);
  res.json({ ok: true });
});

app.post('/api/preview-code', async (req, res) => {
  const config = await getConfig();
  const code = buildDrawingCode(req.body);
  const folderName = buildFolderName({ ...req.body, code });
  res.json({ code, folderName });
});

app.post('/api/create-project', async (req, res) => {
  const config = await getConfig();
  const code = buildDrawingCode(req.body);
  const safeCode = sanitizeSegment(code);
  const safeTitle = sanitizeSegment(req.body.title || '프로젝트가제') || '프로젝트가제';
  const folderName = buildFolderName({ ...req.body, code: safeCode });
  const safeFolder = folderName || safeCode;

  const targetRoot = req.body.outputRoot || config.outputRoot;
  const targetDir = path.join(targetRoot, safeFolder);
  await fse.ensureDir(targetDir);

  const nxTemplate = req.body.nxTemplatePath || config.nxTemplatePath;
  if (nxTemplate && fs.existsSync(nxTemplate)) {
    const ext = path.extname(nxTemplate) || '.prt';
    const dest = path.join(targetDir, `${safeCode}-${safeTitle}${ext}`);
    await fse.copy(nxTemplate, dest);
  }

  const memoHtml = projectMemoHtml({
    code: safeCode,
    title: req.body.title,
    owner: req.body.owner,
    ownerPosition: req.body.ownerPosition,
    customer: req.body.customer,
    siteLabel: config.sites.find((s) => s.id === req.body.site)?.label || '',
    group: req.body.group,
    contact: req.body.contact,
    orders: req.body.orders || [],
    memo: req.body.memo
  });
  const memoPath = path.join(targetDir, `${safeCode}-${safeTitle}-MEMO.html`);
  await fsp.writeFile(memoPath, memoHtml, 'utf8');

  const quotationTemplate = config.quotationTemplatePath;
  if (quotationTemplate && fs.existsSync(quotationTemplate)) {
    const quotationName = `견적서-${safeTitle || '프로젝트가제'}.html`;
    const quotationPath = path.join(targetDir, quotationName);
    await fse.copy(quotationTemplate, quotationPath);

    const stampPath = path.join(TEMPLATE_DIR, 'stamp.png');
    if (fs.existsSync(stampPath)) {
      // quotation.html 템플릿이 Source/stamp.png 를 참조하므로 동일 구조로 복사
      const sourceDir = path.join(targetDir, 'Source');
      await fse.ensureDir(sourceDir);
      await fse.copy(stampPath, path.join(sourceDir, 'stamp.png'));
      // 혹시 모를 참조를 위해 루트에도 함께 복사
      await fse.copy(stampPath, path.join(targetDir, 'stamp.png'));
    }
  }

  const meta = {
    ...req.body,
    code: safeCode,
    folderName: safeFolder,
    createdAt: new Date().toISOString()
  };
  await fsp.writeFile(path.join(targetDir, `${safeCode}.json`), JSON.stringify(meta, null, 2), 'utf8');

  res.json({ ok: true, code: safeCode, folder: targetDir });
});

ensureDataFiles().then(() => {
  app.listen(PORT, () => {
    console.log(`START app ready on http://localhost:${PORT}`);
  });
});

